﻿// See https://aka.ms/new-console-template for more information
using System.Runtime.ConstrainedExecution;

//Zdroje:
//      https://www.tutorialsteacher.com/articles/generate-random-numbers-in-csharp


Console.Title = "Cesta za pokladem";
Console.WriteLine("Jak se budeš chtít ve hře jmenovat?");
string jmeno = Console.ReadLine();

int penize = 3;
int stamina = 100;
int karma = 0;
int kola = 1;

Console.Clear();
Console.WriteLine("Vítej ve hře, " + jmeno + ".");
Console.WriteLine("1. Pozorně si čti text.");
Console.WriteLine("2. Na otázky, kde budeš muset odpovědět číslem, nepiš slova ani písmena (pouze čísla).");
Console.WriteLine("3. V každém kole budeš mít na výběr z několika možností, vybírej chytře.");
Console.WriteLine("4. Dej pozor na počet dolarů a čas (kola). Když hru nedokončíš do určitého kola (hra sama vybere počet kol), najde poklad někdo jiný a pro tebe hra končí.");
Console.WriteLine("5. Dej si pozor na karmu, zvyšuje nebo snižuje pravděpodobnost úspěchu (tuto hodnotu nebudeš moci zobrazit).");
Console.WriteLine("6. Když budeš chtít pokračovat (a nebude zrovna napsaná žádná otázka či rozhodnutí), stiskni Enter.");
Console.WriteLine("7. Pokud ti stamina klesne pod 50, bude ti všechno trvat dvakrát déle (bude ti to trvat dvakrát více kol).");
Console.ReadKey();
Console.Clear();

Console.WriteLine("Máš " + penize + " dolarů");
Console.WriteLine(kola + ". Kolo");
Console.WriteLine("Máš " + stamina + " staminy");


Console.WriteLine("\nPíše se rok 1860 a ty žiješ v malém domku se svou manželkou a dcerou, která vážně onemocněla. Na její léčbu ale nemáš dostatek peněz. Pracuješ v místní hospodě, kde vyslechneš zajímavý rozhovor. Dva muži nad půllitrem debatují o vzácném ztraceném pokladu, o kterém ale nikdo neví, jestli existuje, protože z cesty za pokladem se ještě nikdo nikdy nevrátil. Zní to sice nebezpečně a nevíš, jestli je poklad skutečný, ale je to tvá jediná naděje na uzdravení své dcery. Rozhodneš se vše vsadit na jednu kartu a jsi odhodlaný poklad najít.");
Console.ReadLine();

string vec1 = "";
string vec2 = "";
string vec3 = "";
string vec4 = "";

int vec1_konec = 0;
while (vec1_konec != 1)
{
    Console.Clear();
    Console.WriteLine("Máš " + penize + " dolarů");
    Console.WriteLine(kola + ". Kolo");
    Console.WriteLine("Máš " + stamina + " staminy");

    Console.WriteLine("\nNa tak těžkou cestu ale nemůžeš vyrazit s prázdnýma rukama. Doma vyskládáš na stůl několik věcí, ale můžeš si vybrat pouze čtyři. Které to budou? (Po každém zvoleném čísle stiskni Enter)");
    Console.WriteLine("\n1. Peníze navíc (4 dolary)");
    Console.WriteLine("2. Oblečení");
    Console.WriteLine("3. Jídlo");
    Console.WriteLine("4. Nůž");
    Console.WriteLine("5. Lano");
    Console.WriteLine("6. Láhev");
    Console.WriteLine("7. Sirky");
    Console.WriteLine("8. Fotka tvé rodiny");
    Console.WriteLine("9. Spací pytel");
    Console.WriteLine("10. Kniha");

    Console.WriteLine("\nJakou budeš chtít první věc?");

    vec1 = Console.ReadLine();
    if (vec1 == "1" || vec1 == "2" || vec1 == "3" || vec1 == "4" || vec1 == "5" || vec1 == "6" || vec1 == "7" || vec1 == "8" || vec1 == "9" || vec1 == "10")
    {
        vec1_konec = 1;
        Console.WriteLine("Výborně, číslo bylo vybráno.");

        if (vec1 == "1" || vec2 == "1" || vec3 == "1" || vec4 == "1")
        {
            penize = 7;
        }
        if (vec1 == "2" || vec2 == "2" || vec3 == "2" || vec4 == "2")
        {
            stamina += 50;
        }
        else if (vec1 == "3" || vec2 == "3" || vec3 == "3" || vec4 == "3")
        {
            stamina += 50;
        }
        else if (vec1 == "6" || vec2 == "6" || vec3 == "6" || vec4 == "6")
        {
            stamina += 50;
        }
        else if (vec1 == "8" || vec2 == "8" || vec3 == "8" || vec4 == "8")
        {
            stamina += 50;
        }
        else if (vec1 == "9" || vec2 == "9" || vec3 == "9" || vec4 == "9")
        {
            stamina += 50;
        }
        else if (vec1 == "10" || vec2 == "10" || vec3 == "10" || vec4 == "10")
        {
            stamina += 50;
        }        
        
        Console.ReadLine();
    }
    else
    {
        Console.WriteLine("Toto číslo není k dispozici, nebo toto číslo už bylo vybrané.");
        Console.ReadLine();
    }
}

int vec2_konec = 0;
while (vec2_konec != 1)
{
    Console.Clear();
    Console.WriteLine("Máš " + penize + " dolarů");
    Console.WriteLine(kola + ". Kolo");
    Console.WriteLine("Máš " + stamina + " staminy");

    Console.WriteLine("\nNa tak těžkou cestu ale nemůžeš vyrazit s prázdnýma rukama. Doma vyskládáš na stůl několik věcí, ale můžeš si vybrat pouze čtyři. Které to budou? (Po každém zvoleném čísle stiskni Enter)");
    Console.WriteLine("\n1. Peníze navíc (4 dolary)");
    Console.WriteLine("2. Oblečení");
    Console.WriteLine("3. Jídlo");
    Console.WriteLine("4. Nůž");
    Console.WriteLine("5. Lano");
    Console.WriteLine("6. Láhev");
    Console.WriteLine("7. Sirky");
    Console.WriteLine("8. Fotka tvé rodiny");
    Console.WriteLine("9. Spací pytel");
    Console.WriteLine("10. Kniha");

    Console.WriteLine("\nJakou budeš chtít druhou věc?");

    vec2 = Console.ReadLine();
    if (vec2 == "1" || vec2 == "2" || vec2 == "3" || vec2 == "4" || vec2 == "5" || vec2 == "6" || vec2 == "7" || vec2 == "8" || vec2 == "9" || vec2 == "10")
    {
        if (vec1 != vec2)
        {
            vec2_konec = 1;
            Console.WriteLine("Výborně, číslo bylo vybráno.");

            if (vec1 == "1" || vec2 == "1" || vec3 == "1" || vec4 == "1")
            {
                penize = 7;
            }
            if (vec1 == "2" || vec2 == "2" || vec3 == "2" || vec4 == "2")
            {
                stamina += 50;
            }
            else if (vec1 == "3" || vec2 == "3" || vec3 == "3" || vec4 == "3")
            {
                stamina += 50;
            }
            else if (vec1 == "6" || vec2 == "6" || vec3 == "6" || vec4 == "6")
            {
                stamina += 50;
            }
            else if (vec1 == "8" || vec2 == "8" || vec3 == "8" || vec4 == "8")
            {
                stamina += 50;
            }
            else if (vec1 == "9" || vec2 == "9" || vec3 == "9" || vec4 == "9")
            {
                stamina += 50;
            }
            else if (vec1 == "10" || vec2 == "10" || vec3 == "10" || vec4 == "10")
            {
                stamina += 50;
            }
            
            Console.ReadLine();
        }
        else
        {
            Console.WriteLine("Toto číslo není k dispozici, nebo toto číslo už bylo vybrané.");
            Console.ReadLine();
        }
    }
    else
    {
        Console.WriteLine("Toto číslo není k dispozici, nebo toto číslo už bylo vybrané.");
        Console.ReadLine();
    }
}

int vec3_konec = 0;
while (vec3_konec != 1)
{
    Console.Clear();
    Console.WriteLine("Máš " + penize + " dolarů");
    Console.WriteLine(kola + ". Kolo");
    Console.WriteLine("Máš " + stamina + " staminy");

    Console.WriteLine("\nNa tak těžkou cestu ale nemůžeš vyrazit s prázdnýma rukama. Doma vyskládáš na stůl několik věcí, ale můžeš si vybrat pouze čtyři. Které to budou? (Po každém zvoleném čísle stiskni Enter)");
    Console.WriteLine("\n1. Peníze navíc (4 dolary)");
    Console.WriteLine("2. Oblečení");
    Console.WriteLine("3. Jídlo");
    Console.WriteLine("4. Nůž");
    Console.WriteLine("5. Lano");
    Console.WriteLine("6. Láhev");
    Console.WriteLine("7. Sirky");
    Console.WriteLine("8. Fotka tvé rodiny");
    Console.WriteLine("9. Spací pytel");
    Console.WriteLine("10. Kniha");

    Console.WriteLine("\nJakou budeš chtít třetí věc?");

    vec3 = Console.ReadLine();
    if (vec3 == "1" || vec3 == "2" || vec3 == "3" || vec3 == "4" || vec3 == "5" || vec3 == "6" || vec3 == "7" || vec3 == "8" || vec3 == "9" || vec3 == "10")
    {
        if (vec3 != vec1 && vec3 != vec2)
        {
            vec3_konec = 1;
            Console.WriteLine("Výborně, číslo bylo vybráno.");

            if (vec1 == "1" || vec2 == "1" || vec3 == "1" || vec4 == "1")
            {
                penize = 7;
            }
            if (vec1 == "2" || vec2 == "2" || vec3 == "2" || vec4 == "2")
            {
                stamina += 50;
            }
            else if (vec1 == "3" || vec2 == "3" || vec3 == "3" || vec4 == "3")
            {
                stamina += 50;
            }
            else if (vec1 == "6" || vec2 == "6" || vec3 == "6" || vec4 == "6")
            {
                stamina += 50;
            }
            else if (vec1 == "8" || vec2 == "8" || vec3 == "8" || vec4 == "8")
            {
                stamina += 50;
            }
            else if (vec1 == "9" || vec2 == "9" || vec3 == "9" || vec4 == "9")
            {
                stamina += 50;
            }
            else if (vec1 == "10" || vec2 == "10" || vec3 == "10" || vec4 == "10")
            {
                stamina += 50;
            }

            Console.ReadLine();
        }
        else
        {
            Console.WriteLine("Toto číslo není k dispozici, nebo toto číslo už bylo vybrané.");
            Console.ReadLine();
        }
    }
    else
    {
        Console.WriteLine("Toto číslo není k dispozici, nebo toto číslo už bylo vybrané.");
        Console.ReadLine();
    }
}

int vec4_konec = 0;
while (vec4_konec != 1)
{
    Console.Clear();
    Console.WriteLine("Máš " + penize + " dolarů");
    Console.WriteLine(kola + ". Kolo");
    Console.WriteLine("Máš " + stamina + " staminy");

    Console.WriteLine("\nNa tak těžkou cestu ale nemůžeš vyrazit s prázdnýma rukama. Doma vyskládáš na stůl několik věcí, ale můžeš si vybrat pouze čtyři. Které to budou? (Po každém zvoleném čísle stiskni Enter)");
    Console.WriteLine("\n1. Peníze navíc (4 dolary)");
    Console.WriteLine("2. Oblečení");
    Console.WriteLine("3. Jídlo");
    Console.WriteLine("4. Nůž");
    Console.WriteLine("5. Lano");
    Console.WriteLine("6. Láhev");
    Console.WriteLine("7. Sirky");
    Console.WriteLine("8. Fotka tvé rodiny");
    Console.WriteLine("9. Spací pytel");
    Console.WriteLine("10. Kniha");

    Console.WriteLine("\nJakou budeš chtít čtvrtou věc?");

    vec4 = Console.ReadLine();
    if (vec4 == "1" || vec4 == "2" || vec4 == "3" || vec4 == "4" || vec4 == "5" || vec4 == "6" || vec4 == "7" || vec4 == "8" || vec4 == "9" || vec4 == "10")
    {
        if (vec4 != vec1 && vec4 != vec2 && vec4 != vec3)
        {
            vec4_konec = 1;
            Console.WriteLine("Výborně, číslo bylo vybráno.");

            if (vec1 == "1" || vec2 == "1" || vec3 == "1" || vec4 == "1")
            {
                penize = 7;
            }
            if (vec1 == "2" || vec2 == "2" || vec3 == "2" || vec4 == "2")
            {
                stamina += 50;
            }
            else if (vec1 == "3" || vec2 == "3" || vec3 == "3" || vec4 == "3")
            {
                stamina += 50;
            }
            else if (vec1 == "6" || vec2 == "6" || vec3 == "6" || vec4 == "6")
            {
                stamina += 50;
            }
            else if (vec1 == "8" || vec2 == "8" || vec3 == "8" || vec4 == "8")
            {
                stamina += 50;
            }
            else if (vec1 == "9" || vec2 == "9" || vec3 == "9" || vec4 == "9")
            {
                stamina += 50;
            }
            else if (vec1 == "10" || vec2 == "10" || vec3 == "10" || vec4 == "10")
            {
                stamina += 50;
            }

            Console.ReadLine();
        }
        else
        {
            Console.WriteLine("Toto číslo není k dispozici, nebo toto číslo už bylo vybrané.");
            Console.ReadLine();
        }
    }
    else
    {
        Console.WriteLine("Toto číslo není k dispozici, nebo toto číslo už bylo vybrané.");
        Console.ReadLine();
    }
}

kola++;

Console.Clear();

stamina = stamina - 10;

Console.WriteLine("Máš " + penize + " dolarů");
Console.WriteLine(kola + ". Kolo");
Console.WriteLine("Máš " + stamina + " staminy");

Console.WriteLine("\nSvé ženě a dceři oznamuješ, že se vydáváš na dlouhou cestu a že každá vzpomínka na ně tě bude hnát dopředu. Se slzami v očích naposledy obě objímáš a odcházíš.");
string cast2 = Console.ReadLine();

if (cast2 == "Konec")
{
    return;
}
Console.Clear();

string koupeni_mapy = "";
string koupeni_mapy2 = "";

if (vec1 == "1" || vec2 == "1" || vec3 == "1" || vec4 == "1")
{
    int cast3_konec = 0;
    while (cast3_konec != 1)
    {
        Console.Clear();
        Console.WriteLine("Máš " + penize + " dolarů");
        Console.WriteLine(kola + ". Kolo");
        Console.WriteLine("Máš " + stamina + " staminy");

        Console.WriteLine("\nDorazíš do města a začneš se ptát lidí na poklad. Mnoho z nich tě ignoruje, nebo ti začne nadávat. Nakonec ale přece jen narazíš na muže, který ví o třech obchodnících s mapami k pokladu. Každá mapa něco stojí. Tu nejlevnější nabízí obchodník, který má ale ve městě pověst podvodníka. Jelikož máš dostatek peněz, můžeš si koupit kteroukoliv z nich a také dostáváš možnost si přivydělat a získat některé peníze zpátky. Jak se rozhodneš?");

        Console.WriteLine("\n1. Koupit mapu (2 dolary)");
        Console.WriteLine("2. Koupit mapu (4 dolary)");
        Console.WriteLine("3. Koupit mapu (7 dolarů)");
        Console.WriteLine("4. Vydělat si 3 dolary");
        koupeni_mapy = Console.ReadLine();

        if (koupeni_mapy == "Konec")
        {
            return;
        }
        else if (koupeni_mapy == "1")
        {
            Console.WriteLine("Výborně, koupil sis mapu za 2 dolarů.");
            Console.ReadKey();
            Console.Clear();
            penize = penize - 2;
            cast3_konec = 1;
        }
        else if (koupeni_mapy == "2")
        {
            Console.WriteLine("Výborně, koupil sis mapu za 4 dolarů.");
            Console.ReadKey();
            Console.Clear();
            penize = penize - 4;
            cast3_konec = 1;
        }
        else if (koupeni_mapy == "3")
        {
            Console.WriteLine("Výborně, koupil sis mapu za 7 dolarů.");
            Console.ReadKey();
            Console.Clear();
            penize -= 7;
            cast3_konec = 1;

        }
        else if (koupeni_mapy == "4")
        {
            stamina -= 10;
            kola++;
            Console.Clear();
            Console.WriteLine("Ve městě si najdeš jednorázovou práci v místním obchodě. Pro získání peněz musíš vypočítat tento příklad:");
            Console.WriteLine("2 + 3 * 7");
            
            string hadanka1 = Console.ReadLine();
            
            if (hadanka1 == "23")
            {
                penize += 3;
                Console.WriteLine("\nVýborně, příklad jsi vypočítal správně.");
                Console.WriteLine("Získáváš 3 dolary, a tudíž máš u sebe " + penize + " dolarů.");
                cast3_konec = 1;
                Console.ReadKey();
            }
            else
            {
                Console.WriteLine("\nBohužel špatně");
                Console.WriteLine("Nezískáváš nic a máš u sebe stále " + penize + " dolarů");
                cast3_konec = 1;
                Console.ReadKey();
            }
            
            int cast3_1_konec = 0;
            
            while (cast3_1_konec != 1)
            {
                Console.Clear();
                Console.WriteLine("Máš " + penize + " dolarů");
                Console.WriteLine(kola + ". Kolo");
                Console.WriteLine("Máš " + stamina + " staminy");

                Console.WriteLine("\nVyber si z těchto možností:");
                Console.WriteLine("1. Koupit mapu (2 dolary)");
                Console.WriteLine("2. Koupit mapu (4 dolary)");
                Console.WriteLine("3. Koupit mapu (7 dolarů)");
                koupeni_mapy2 = Console.ReadLine();

                if (koupeni_mapy2 == "1")
                {
                    if (penize >= 2)
                    {
                        penize -= 2;
                        cast3_1_konec = 1;
                        Console.WriteLine("Výborně, koupil sis mapu za 2 dolary");
                        Console.ReadKey();
                    }
                    else
                    {
                        Console.WriteLine("Nemáš dostatek dolarů");
                        Console.ReadKey();
                    }
                }
                else if (koupeni_mapy2 == "2")
                {
                    if (penize >= 4)
                    {
                        penize -= 4;
                        cast3_1_konec = 1;
                        Console.WriteLine("Výborně, koupil sis mapu za 4 dolary");
                        Console.ReadKey();
                    }
                    else
                    {
                        Console.WriteLine("Nemáš dostatek dolarů");
                        Console.ReadKey();
                    }
                }
                else if (koupeni_mapy2 == "3")
                {
                    if (penize >= 7)
                    {
                        penize -= 7;
                        cast3_1_konec = 1;
                        Console.WriteLine("Výborně, koupil sis mapu za 7 dolarů.");
                        Console.ReadKey();
                    }
                    else
                    {
                        Console.WriteLine("Nemáš dostatek dolarů.");
                        Console.ReadKey();
                    }
                }
            }
        }
    }
}
else
{

    int cast3_konec = 0;

    while (cast3_konec != 1)
    {
        Console.Clear();
        Console.WriteLine("Máš " + penize + " dolarů");
        Console.WriteLine(kola + ". Kolo");
        Console.WriteLine("Máš " + stamina + " staminy");
        Console.WriteLine("\nDorazíš do města a začneš se ptát lidí na poklad. Mnoho z nich tě ignoruje, nebo ti začne nadávat. Nakonec ale přece jen narazíš na muže, který ví o třech obchodnících s mapami k pokladu. Každá mapa něco stojí. Tu nejlevnější nabízí obchodník, který má ale ve městě pověst podvodníka. Protože nemáš moc peněz, budeš si muset koupit tuto, nebo si budeš muset nějaké peníze přivydělat. Jak se rozhodneš? ");
        Console.WriteLine("\n1. Koupit mapu (2 dolary)");
        Console.WriteLine("2. Vydělat si 3 dolary");
        koupeni_mapy = Console.ReadLine();
        if (koupeni_mapy == "Konec")
        {
            return;
        }
        else if (koupeni_mapy == "1")
        {
            cast3_konec = 1;
            penize -= 2;
            Console.WriteLine("Výborně, koupil sis mapu za 2 dolary");
            Console.ReadKey();
        }
        else if (koupeni_mapy == "2")
        {
            stamina -= 10;
            kola++;
            Console.Clear();
            Console.WriteLine("Ve městě si najdeš jednorázovou práci v místním obchodě. Pro získání peněz musíš vypočítat tento příklad:");
            Console.WriteLine("2 + 3 * 7");

            string hadanka1 = Console.ReadLine();

            if (hadanka1 == "23")
            {
                penize += 3;
                Console.WriteLine("\nVýborně, příklad jsi vypočítal správně.");
                Console.WriteLine("Získáváš 3 dolary, a tudíž máš u sebe " + penize + " dolarů.");
                cast3_konec = 1;
                Console.ReadKey();
            }
            else
            {
                Console.WriteLine("\nBohužel špatně");
                Console.WriteLine("Nezískáváš nic a máš u sebe stále " + penize + " dolarů");
                cast3_konec = 1;
                Console.ReadKey();
            }

            int cast3_1_konec = 0;

            while (cast3_1_konec != 1)
            {
                Console.Clear();
                Console.WriteLine("Máš " + penize + " dolarů");
                Console.WriteLine(kola + ". Kolo");
                Console.WriteLine("Máš " + stamina + " staminy");

                Console.WriteLine("\nVyber si z těchto možností:");
                Console.WriteLine("1. Koupit mapu (2 dolary)");
                Console.WriteLine("2. Koupit mapu (4 dolary)");
                Console.WriteLine("3. Koupit mapu (7 dolarů)");
                koupeni_mapy2 = Console.ReadLine();

                if (koupeni_mapy2 == "1")
                {
                    if (penize >= 2)
                    {
                        penize -= 2;
                        cast3_1_konec = 1;
                        Console.WriteLine("Výborně, koupil sis mapu za 2 dolary");
                        Console.ReadKey();
                    }
                    else
                    {
                        Console.WriteLine("Nemáš dostatek dolarů");
                        Console.ReadKey();
                    }
                }
                else if (koupeni_mapy2 == "2")
                {
                    if (penize >= 4)
                    {
                        penize -= 4;
                        cast3_1_konec = 1;
                        Console.WriteLine("Výborně, koupil sis mapu za 4 dolary");
                        Console.ReadKey();
                    }
                    else
                    {
                        Console.WriteLine("Nemáš dostatek dolarů");
                        Console.ReadKey();
                    }
                }
                else if (koupeni_mapy2 == "3")
                {
                    if (penize >= 7)
                    {
                        penize -= 7;
                        cast3_1_konec = 1;
                        Console.WriteLine("Výborně, koupil sis mapu za 7 dolarů");
                        Console.ReadKey();
                    }
                    else
                    {
                        Console.WriteLine("Nemáš dostatek dolarů");
                        Console.ReadKey();
                    }
                }
            }

        }
    }
}
if (koupeni_mapy == "1" || koupeni_mapy2 == "1")
{
    Console.Clear();
    Console.WriteLine("Máš " + penize + " dolarů");
    Console.WriteLine(kola + ". Kolo");
    Console.WriteLine("Máš " + stamina + " staminy");

    Console.WriteLine("\nOdcházíš z města a orientuješ se podle mapy. Naštěstí vidíš bod na mapě, kam si za mlada chodíval. Jdeš tedy tím směrem.");
    Console.ReadLine();
    kola++;

    stamina -= 10;

    Console.Clear();
    Console.WriteLine("Máš " + penize + " dolarů");
    Console.WriteLine(kola + ". Kolo");
    Console.WriteLine("Máš " + stamina + " staminy");

    Console.WriteLine("\nPo chvíli cesty dojdeš k bodu, který jsi kdysi znal a je taktéž vyznačen na mapě. Jdeš tedy podle mapy a dorazíš do hospody, která se jmenuje U Zlata. Křížek vyznačen na mapě ukazoval na tuto hospodu. Smutně vejdeš do ní a vidíš noviny, ve kterých je napsáno, že někdo našel poklad. Sice si nejsi stoprocentně jistý, že to je poklad, který jsi hledal, ale řekneš si, že se radši vrátíš domů. Rodina tě ráda vidí, ale ty jsi ze sebe zklamaný, protože ses nechal nachytat od falešného prodavače map k pokladu.");
    return;
}

Console.Clear();
Console.WriteLine("Máš " + penize + " dolarů");
Console.WriteLine(kola + ". Kolo");
Console.WriteLine("Máš " + stamina + " staminy");

Console.WriteLine("\nZískal jsi mapu, ale stále nevíš, kde začíná a jakým směrem se tedy máš vydat. V tomto městě ti nikdo nepomůže, musíš tedy pokračovat dál.");
Console.ReadLine();

stamina -= 10;
kola++;

if (vec1 == "5" || vec2 == "5" || vec3 == "5" || vec4 == "5")
{
    int cast6_konec = 0;
    while (cast6_konec != 1)
    {
        Console.Clear();
        Console.WriteLine("Máš " + penize + " dolarů");
        Console.WriteLine(kola + ". Kolo");
        Console.WriteLine("Máš " + stamina + " staminy");

        Console.WriteLine("\nDošel jsi k vysokým horám. Jelikož máš u sebe lano, můžeš na hory vylézt a ušetřit si tak dost času, nebo je obejít dlouhou cestou.");
        Console.WriteLine("\n1. Vyšplhat horu (hádanka)");
        Console.WriteLine("2. Obejít horu (3 kola)");
        string vyber_hora = Console.ReadLine();

        if (vyber_hora == "1")
        {
            cast6_konec = 1;

            Console.Clear();
            Console.WriteLine("Lezeš na horu a potřebuješ vypočítat, za jak dlouho horu vyšplháš. Pokud lezeš průměrnou rychlostí 0,5 km/h a hora je vysoká 250 m. Za kolik minut horu vylezeš? (Použij pouze číslice např. 2; nepiš k tomu minuty a neodpovídej celými větami, pouze číslice)");
            string hadanka2 = Console.ReadLine();

            if (hadanka2 == "30")
            {
                Console.WriteLine("Výborně, horu si uspěšně přelezl.");
                Console.ReadLine();
                
                kola++;
                stamina -= 10;
            }
            else
            {
                Console.WriteLine("Bohužel se ti hora nepovedla přelézt a musíš ji obejít.");
                Console.ReadLine();

                kola += 4;
                stamina -= 10;
            }
        }
        else if (vyber_hora == "2")
        {
            cast6_konec = 1;
            Console.WriteLine("Horu obcházíš.");
            Console.ReadLine();

            kola += 3;
            stamina -= 10;
        }
    }
    
}
else
{
    int cast6_konec = 0;
    while (cast6_konec != 1)
    {
        Console.Clear();
        Console.WriteLine("Máš " + penize + " dolarů");
        Console.WriteLine(kola + ". Kolo");
        Console.WriteLine("Máš " + stamina + " staminy");

        Console.WriteLine("\nDošel jsi k vysokým horám. Jelikož nemáš lano, které by ti pomohlo na hory vylézt, musíš je obejít mnohem delší cestou.");
        Console.WriteLine("\n1. Obejít horu (3 kola)");
        string vyber_hora = Console.ReadLine();

        if (vyber_hora == "1")
        {
            Console.WriteLine("Horu obcházíš.");
            Console.ReadLine();

            cast6_konec = 1;
            kola += 3;
            stamina -= 10;
        }
    }

}

int cast7_1_konec = 0;
while (cast7_1_konec != 1)
{
    Console.Clear();
    Console.WriteLine("Máš " + penize + " dolarů");
    Console.WriteLine(kola + ". Kolo");
    Console.WriteLine("Máš " + stamina + " staminy");

    Console.WriteLine("\nHory jsi už nechal za sebou a přicházíš k malé chatě, ze které tě zdraví stařenka. Nabídne ti dolar za to, že jí doneseš byliny. Přijmeš její nabídku?");
    Console.WriteLine("1. Ano");
    Console.WriteLine("2. Ne");
    string pridelat_cast7 = Console.ReadLine();

    if (pridelat_cast7 == "1")
    {
        Console.Clear();
        penize++;
        Console.WriteLine("Po úspěšné pomoci stařence ti dala dolar a máš u sebe " + penize + " dolarů");
        Console.ReadLine();
        cast7_1_konec = 1;

        stamina -= 10;
        kola++;
    }
    else if (pridelat_cast7 == "2")
    {
        cast7_1_konec = 1;

        Console.Clear();
        Console.WriteLine("Stařenku odmítáš a nic si nevyděláváš.");
        Console.ReadLine();
    }
}
Console.Clear();
Console.WriteLine("Máš " + penize + " dolarů");
Console.WriteLine(kola + ". Kolo");
Console.WriteLine("Máš " + stamina + " staminy");

Console.WriteLine("\nSvěříš se jí se svým trápením a ukážeš jí svou mapu. Chvíli si ji prohlíží a nakonec řekne, že ví, kde se tato oblast nachází a ukáže ti cestu.");
Console.ReadLine();
if (stamina < 50)
{
    kola++;
}
stamina -= 10;
kola++;

int naboje = 0;
string zbran = "";

int cast8_konec = 0;
while (cast8_konec != 1)
{
    Console.Clear();
    Console.WriteLine("Máš " + penize + " dolarů");
    Console.WriteLine(kola + ". Kolo");
    Console.WriteLine("Máš " + stamina + " staminy");

    Console.WriteLine("\nPo delší době dorazíš do dalšího města, ve kterém je možnost získat střelnou zbraň ilegálně, nebo se zbrojním průkazem. Jak si zbraň opatříš?");
    Console.WriteLine("1. Zbraň nechceš");
    Console.WriteLine("2. Chceš zbraň se zbrojním průkazem (4 dolary)");
    Console.WriteLine("3. Chceš zbraň bez zbrojního průkazu (2 dolary, snížení karmy)");

    zbran = Console.ReadLine();

    if (zbran == "1")
    {
        cast8_konec = 1;
        Console.Clear();
        Console.WriteLine("Zbraň sis nekoupil.");
        Console.ReadLine();
    }
    else if (zbran == "2")
    {
        if (penize >= 4)
        {
            cast8_konec = 1;
            penize -= 4;
            if (stamina < 50)
            {
                kola++;
            }
            stamina -= 10;
            kola++;

            naboje = 6;

            Console.Clear();
            Console.WriteLine("Koupil sis zbraň se zbrojním průkazem za 4 dolary a máš u sebe " + penize + " dolarů. K tomu ti prodavač prodal 6 nábojů.");
            Console.ReadLine();
        }
        else
        {
            Console.Clear();
            Console.WriteLine("Bohužel nemáš u sebe dostatek dolarů");
            Console.ReadLine();
        }
        
    }
    else if (zbran == "3")
    {
        if (penize >= 2)
        {
            cast8_konec = 1;
            penize -= 2;
            karma -= 1;
            if (stamina < 50)
            {
                kola++;
            }
            stamina -= 10;
            kola++;

            naboje = 6;

            Console.Clear();
            Console.WriteLine("Koupil sis zbraň bez zbrojního průkazu za 2 dolary a máš u sebe " + penize + " dolarů. K tomu ti prodavač prodal 6 nábojů.");
            Console.ReadLine();
        }
        else
        {
            Console.Clear();
            Console.WriteLine("Bohužel nemáš u sebe dostatek dolarů.");
            Console.ReadLine();
        }

    }
}

int cast9_konec = 0;
while (cast9_konec != 1)
{
    Console.Clear();
    Console.WriteLine("Máš " + penize + " dolarů");
    Console.WriteLine(kola + ". Kolo");
    Console.WriteLine("Máš " + stamina + " staminy");

    Console.WriteLine("\nCo budeš dělat ve městě dál? Můžeš jím pouze projít, nebo si zde odpočinout a něco si vydělat v pekárně, nebo si odpočinout a zahrát si v místním kasinu o peníze. Jak se rozhodneš?");
    Console.WriteLine("1. Pouze projít městem");
    Console.WriteLine("2. Odpočinout si a přivydělat si v pekárně (2 dolary)");
    Console.WriteLine("3. Odpočinout si a zahrát si v kasinu");

    string cast9_mesto = Console.ReadLine();

    if (cast9_mesto == "1")
    {
        cast9_konec = 1;
        if (stamina < 50)
        {
            kola++;
        }
        stamina -= 10;
        kola++;
    }
    else if (cast9_mesto == "2")
    {
        cast9_konec = 1;
        stamina += 50;
        kola += 2;

        Console.Clear();
        Console.WriteLine("Dojde do pekárny mladík a ptá se, kolik zaplatí, jestliže si koupí koláč a 6 rohlíků. Koláč stojí 2 dolary, rohlík stojí 0,5 dolaru.");
        string hadanka_pekarna = Console.ReadLine();

        if (hadanka_pekarna == "5")
        {
            penize += 2;
            Console.WriteLine("Správně, získáváš 2 dolary a máš u sebe " + penize + " dolarů.");
            Console.ReadLine();
        }
        else
        {
            Console.WriteLine("Bohužel špatně.");
            Console.ReadLine();
        }
    }
    else if (cast9_mesto == "3")
    {
        cast9_konec = 1;
        stamina += 50;
        kola += 2;

        int cast9_kasino_konec = 0;
        while (cast9_kasino_konec != 1)
        {
            Console.Clear();
            Console.WriteLine("Máš " + penize + " dolarů");
            Console.WriteLine(kola + ". Kolo");
            Console.WriteLine("Máš " + stamina + " staminy");

            Console.WriteLine("\nKolik chceš vsadit? (Používej pouze číslice!!!)");
            int sazka = int.Parse(Console.ReadLine());

            if (penize >= sazka)
            {
                cast9_kasino_konec = 1;
                int pravdepodobnost = karma * 10 + 40;
                
                Random kasino = new Random();
                int kasino1 = kasino.Next(0, 100);

                if (pravdepodobnost >= kasino1)
                {
                    karma -= 1;
                    Console.Clear();
                    penize = penize + sazka;
                    Console.WriteLine("Výborně, vyhrál jsi a svůj vklad zdvojnásobil a máš u sebe " + penize + " dolarů");
                    Console.ReadLine();
                }
                else
                {
                    Console.Clear();
                    penize = penize - sazka;
                    Console.WriteLine("Bohužel jsi prohrál " + sazka + " dolarů. Máš u sebe " + penize + " dolarů.");
                    Console.ReadLine();
                }
            }
            else
            {
                Console.WriteLine("Bohužel nemáš na tuto sázku dostatek dolarů");
                Console.ReadLine();
            }
        }
    }
}

int cast10_konec = 0;
while (cast10_konec != 1)
{
    Console.Clear();
    Console.WriteLine("Máš " + penize + " dolarů");
    Console.WriteLine(kola + ". Kolo");
    Console.WriteLine("Máš " + stamina + " staminy");

    Console.WriteLine("\nOdcházíš z města a najednou k tobě přijde chudá paní, která tě prosí o dolar na jídlo. Dáš jí ho?");
    Console.WriteLine("1. Ano (zvýšení karmy)");
    Console.WriteLine("2. Ne (snížení karmy)");

    string cast10_chuda_pani = Console.ReadLine();

    if (cast10_chuda_pani == "1")
    {
        if (penize >= 1)
        {
            cast10_konec = 1;
            penize -= 1;
            karma += 1;

            Console.Clear();
            Console.WriteLine("Paní ti poděkovala a tobě se zvýšila karma.");
            Console.ReadLine();
        }
        else
        {
            cast10_konec = 1;
            Console.Clear();
            Console.WriteLine("Paní jsi řekl, že taky nic nemáš a ona to pochopila.");
            Console.ReadLine();
        }
    }
    else if (cast10_chuda_pani == "2")
    {
        cast10_konec = 1;
        karma -= 1;

        Console.Clear();
        Console.WriteLine("Dolar jsi jí nedal a odcházíš.");
        Console.ReadLine();
    }
}

int cast11_konec = 0;
while (cast11_konec != 1)
{
    Console.Clear();
    Console.WriteLine("Máš " + penize + " dolarů");
    Console.WriteLine(kola + ". Kolo");
    Console.WriteLine("Máš " + stamina + " staminy");

    Console.WriteLine("\nPo pár hodinách přicházíš na písčitou pláž a jediná cesta dál vede přes moře. Na překonání moře máš několik možností. Můžeš si postavit zdarma svou vlastní loď, nebo můžeš zaplatit místnímu převozníkovi, nebo zaplatíš více peněz za rychlejší loď, která stojí u břehu. Jak se rozhodneš?");
    Console.WriteLine("1. Postavit si vlastní loď (4 kola)");
    Console.WriteLine("2. Zaplatit převozníkovi (2 kola, 2 dolary)");
    Console.WriteLine("3. Zaplatit plavbu rychlejší lodí (1 kolo, 4 dolary)");

    string cast11_lode = Console.ReadLine();

    if (cast11_lode == "1")
    {
        cast11_konec = 1;
        
        if (stamina < 50)
        {
            kola += 4;
        }
        stamina -= 10;
        kola += 4;

        Console.Clear();
        Console.WriteLine("Po pár hodinách hledání materiálu a stavění lodi jsi ji konečně dostavěl a vyrážíš na moře.");
        Console.ReadLine();
    }
    else if (cast11_lode == "2")
    {
        if (penize >= 2)
        {
            cast11_konec = 1;

            if (stamina < 50)
            {
                kola += 2;
            }
            stamina -= 10;
            kola += 2;

            penize -= 2;

            Console.Clear();
            Console.WriteLine("Převozníkovi jsi zaplatil a vyrážíte na moře.");
            Console.ReadLine();
        }
        else
        {
            Console.Clear();
            Console.WriteLine("Bohužel nemáš dostatek peněz");
            Console.ReadLine();
        }
        
    }
    else if (cast11_lode == "3")
    {
        if (penize >= 4)
        {
            cast11_konec = 1;

            if (stamina < 50)
            {
                kola++;
            }
            stamina -= 10;
            kola++;

            penize -= 4;

            Console.Clear();
            Console.WriteLine("Zaplatil jsi převozníkovi, který vlastnil nejrychlejší loď, a vyrážíte na moře.");
        }
        else
        {
            Console.Clear();
            Console.WriteLine("Bohužel nemáš dostatek peněz");
            Console.ReadLine();
        }
    }
}


if (zbran == "2" || zbran == "3")
{
    if (vec1 == "4" || vec2 == "4" || vec3 == "4" || vec4 == "4")
    {
        int cast12_4_konec = 0;
        while (cast12_4_konec != 1)
        {
            Console.Clear();
            Console.WriteLine("Máš " + penize + " dolarů");
            Console.WriteLine(kola + ". Kolo");
            Console.WriteLine("Máš " + stamina + " staminy");

            Console.WriteLine("\nPluješ po moři a trpíš mořskou nemocí. Jakmile se zaraduješ, že máš zase pevnou půdu pod nohama, přepadnou tě dva loupežníci.");
            Console.Write(" Naštěstí máš u sebe nůž i střelnou zbraň, a proto se můžeš proti útočníkům bránit. Nezapomeň, že pokud použiješ střelnou zbraň, budeš muset později koupit náboje, a pokud použiješ nůž, vyhraješ pouze, pokud máš dobrou karmu.");
            Console.WriteLine("\n1. Použij střelnou zbraň");
            Console.WriteLine("2. Použij nůž");

            

            string cast12_4_vyber = Console.ReadLine();

            if (cast12_4_vyber == "2")
            {
                cast12_4_konec = 1;
                if (stamina < 50)
                    {
                        kola++;
                    }
                stamina -= 10;
                kola++;

                int cast12_4_pravdepodobnost = karma * 10 + 70;

                Random cast12_4_nuz = new Random();
                int cast12_4_nuz1 = cast12_4_nuz.Next(0, 100);

                if (cast12_4_pravdepodobnost <= cast12_4_nuz1)
                {
                    Console.Clear();
                    Console.WriteLine("Podařilo se ti loupežníky zahnat a všimneš si, že při útěku jim vypadly z kapes 2 dolary. Peníze si vezmeš a můžeš pokračovat v cestě.");
                    penize += 2;
                    karma -= 1;
                    Console.ReadLine();
                }
                else
                {
                    Console.Clear();
                    if (penize > 5)
                    {
                        penize -= 3;
                        Console.WriteLine("Nepodařilo se ti loupežníky zahnat a okradli tě o 3 dolary.");
                        Console.ReadLine();
                    }
                    else if (penize > 0)
                    {
                        penize -= 1;
                        Console.WriteLine("Nepodařilo se ti loupežníky zahnat a okradli tě o 1 dolar.");
                        Console.ReadLine();
                    }
                    else
                    {
                        stamina -= 20;
                        Console.WriteLine("Poněvadž u sebe nemáš žádné peníze, loupežníci tě nechají na pokoji, ale ty ztrátíš část staminy.");
                        Console.ReadLine();
                    }
                }
            }
            else if (cast12_4_vyber == "1")
            {
                cast12_4_konec = 1;

                Console.Clear();
                Console.WriteLine("Napiš číslo pí zaokrouhlené na setiny.");

                if (stamina < 50)
                {
                    kola++;
                }
                stamina -= 10;
                kola++;

                string cast12_4_hadanka = Console.ReadLine();

                Random cast12_4_naboje = new Random();
                int cast12_4_naboje1 = cast12_4_naboje.Next(1, 5);

                naboje = naboje - cast12_4_naboje1;

                if (cast12_4_hadanka == "3.14" || cast12_4_hadanka == "3,14")
                {
                    penize += 2;
                    Console.WriteLine("Podařilo se ti loupežníky zahnat a všimneš si, že při útěku jim vypadly z kapes 2 dolary. Peníze si vezmeš a můžeš pokračovat v cestě. Přijdeš bohužel o " + cast12_4_naboje1 + " nábojů a máš tudíž u sebe " + naboje + " nábojů.");
                    Console.ReadLine();
                }
                else
                {
                    Console.Clear();
                    if (penize > 5)
                    {
                        penize -= 3;
                        Console.WriteLine("Nepodařilo se ti loupežníky zahnat a okradli tě o 3 dolary. Přijdeš bohužel o " + cast12_4_naboje1 + " nábojů a máš tudíž u sebe " + naboje + " nábojů.");
                        Console.ReadLine();
                    }
                    else if (penize > 0)
                    {
                        penize -= 1;
                        Console.WriteLine("Nepodařilo se ti loupežníky zahnat a okradli tě o 1 dolar. Přijdeš bohužel o " + cast12_4_naboje1 + " nábojů a máš tudíž u sebe " + naboje + " nábojů.");
                        Console.ReadLine();
                    }
                    else
                    {
                        stamina -= 20;
                        Console.WriteLine("Poněvadž u sebe nemáš žádné peníze, loupežníci tě nechají na pokoji, ale ty ztrátíš část staminy. Přijdeš bohužel o " + cast12_4_naboje1 + " nábojů a máš tudíž u sebe " + naboje + " nábojů.");
                        Console.ReadLine();
                    }
                }
                
            }
        }
        
    }
    else
    {
        Console.Clear();
        Console.WriteLine("Máš " + penize + " dolarů");
        Console.WriteLine(kola + ". Kolo");
        Console.WriteLine("Máš " + stamina + " staminy");

        Console.WriteLine("\nPluješ po moři a trpíš mořskou nemocí. Jakmile se zaraduješ, že máš zase pevnou půdu pod nohama, přepadnou tě dva loupežníci.");
        Console.Write(" Naštěstí máš u sebe zbraň, a proto se můžeš proti útočníkům bránit.");
        Console.WriteLine("\nNapiš číslo pí zaokrouhlené na setiny.");

        if (stamina < 50)
        {
            kola++;
        }
        stamina -= 10;
        kola++;

        string cast12_3_hadanka = Console.ReadLine();

        Random cast12_3_naboje = new Random();
        int cast12_3_naboje1 = cast12_3_naboje.Next(1, 6);

        naboje = naboje - cast12_3_naboje1;

        if (cast12_3_hadanka == "3.14" || cast12_3_hadanka == "3,14")
        {
            penize += 2;
            Console.WriteLine("Podařilo se ti loupežníky zahnat a všimneš si, že při útěku jim vypadly z kapes 2 dolary. Peníze si vezmeš a můžeš pokračovat v cestě. Přijdeš bohužel o " + cast12_3_naboje1 + " nábojů a máš tudíž u sebe " + naboje + " nábojů.");
            Console.ReadLine();
        }
        else
        {
            Console.Clear();
            if (penize > 5)
            {
                penize -= 3;
                Console.WriteLine("Nepodařilo se ti loupežníky zahnat a okradli tě o 3 dolary. Přijdeš bohužel o " + cast12_3_naboje1 + " nábojů a máš tudíž u sebe " + naboje + " nábojů.");
                Console.ReadLine();
            }
            else if (penize > 0)
            {
                penize -= 1;
                Console.WriteLine("Nepodařilo se ti loupežníky zahnat a okradli tě o 1 dolar. Přijdeš bohužel o " + cast12_3_naboje1 + " nábojů a máš tudíž u sebe " + naboje + " nábojů.");
                Console.ReadLine();
            }
            else
            {
                stamina -= 20;
                Console.WriteLine("Poněvadž u sebe nemáš žádné peníze, loupežníci tě nechají na pokoji, ale ty ztrátíš část staminy. Přijdeš bohužel o " + cast12_3_naboje1 + " nábojů a máš tudíž u sebe " + naboje + " nábojů.");
                Console.ReadLine();
            }
        }
    }
}
else
{
    if (vec1 == "4" || vec2 == "4" || vec3 == "4" || vec4 == "4")
    {
        Console.Clear();
        Console.WriteLine("Máš " + penize + " dolarů");
        Console.WriteLine(kola + ". Kolo");
        Console.WriteLine("Máš " + stamina + " staminy");

        if (stamina < 50)
        {
            kola++;
        }
        stamina -= 10;
        kola++;

        Console.WriteLine("\nPluješ po moři a trpíš mořskou nemocí. Jakmile se zaraduješ, že máš zase pevnou půdu pod nohama, přepadnou tě dva loupežníci.");
        Console.Write(" Naštěstí máš u sebe nůž, a proto se můžeš proti útočníkům bránit.");
        Console.ReadLine();

        int cast12_2_pravdepodobnost = karma * 10 + 70;

        Random cast12_2_nuz = new Random();
        int cast12_2_nuz1 = cast12_2_nuz.Next(0, 100);

        if (cast12_2_pravdepodobnost <= cast12_2_nuz1)
        {
            Console.Clear();
            Console.WriteLine("Podařilo se ti loupežníky zahnat a všimneš si, že při útěku jim vypadly z kapes 2 dolary. Peníze si vezmeš a můžeš pokračovat v cestě.");
            penize += 2;
            karma -= 1;
            Console.ReadLine();
        }
        else
        {
            Console.Clear();
            if (penize > 5)
            {
                penize -= 3;
                Console.WriteLine("Nepodařilo se ti loupežníky zahnat a okradli tě o 3 dolary.");
                Console.ReadLine();
            }
            else if (penize > 0)
            {
                penize -= 1;
                Console.WriteLine("Nepodařilo se ti loupežníky zahnat a okradli tě o 1 dolar.");
                Console.ReadLine();
            }
            else
            {
                stamina -= 20;
                Console.WriteLine("Poněvadž u sebe nemáš žádné peníze, loupežníci tě nechají na pokoji, ale ty ztrátíš část staminy.");
                Console.ReadLine();
            }
        }
    }
    else
    {
        if (stamina < 50)
        {
            kola++;
        }
        stamina -= 10;
        kola++;

        Console.Clear();
        Console.WriteLine("Máš " + penize + " dolarů");
        Console.WriteLine(kola + ". Kolo");
        Console.WriteLine("Máš " + stamina + " staminy");

        Console.WriteLine("\nPluješ po moři a trpíš mořskou nemocí. Jakmile se zaraduješ, že máš zase pevnou půdu pod nohama, přepadnou tě dva loupežníci.");
        Console.Write(" Bohužel u sebe nemáš žádnou zbraň, aby ses mohl bránit. Proto musíš dát část svých peněz loupežníkům.");
        Console.ReadLine();

        if (penize > 5)
        {
            penize -= 3;
            Console.WriteLine("Nepodařilo se ti loupežníky zahnat a okradli tě o 3 dolary.");
            Console.ReadLine();
        }
        else if (penize > 0)
        {
            penize -= 1;
            Console.WriteLine("Nepodařilo se ti loupežníky zahnat a okradli tě o 1 dolar.");
            Console.ReadLine();
        }
        else
        {
            stamina -= 20;
            Console.WriteLine("Poněvadž u sebe nemáš žádné peníze, loupežníci tě nechají na pokoji, ale ty ztrátíš část staminy.");
            Console.ReadLine();
        }
    }
}

string cast13_vypomoc = "";

int cast13_konec = 0;
while (cast13_konec != 1)
{
    Console.Clear();
    Console.WriteLine("Máš " + penize + " dolarů");
    Console.WriteLine(kola + ". Kolo");
    Console.WriteLine("Máš " + stamina + " staminy");

    

    Console.WriteLine("\nPřicházíš do dalšího města a potkáš hospodáře, který ti nabídne za výpomoc nějaké peníze. Přijmeš jeho nabídku?");
    Console.WriteLine("1. Ano");
    Console.WriteLine("2. Ne");
    cast13_vypomoc = Console.ReadLine();

    if (cast13_vypomoc == "1")
    {
        cast13_konec = 1;

        if (stamina < 50)
            {
                kola++;
            }
            stamina -= 10;
            kola++;

        Console.Clear();
        Console.WriteLine("Poněvadž má hospodář krávu, zeptá se tě, jestli víš, kolik má kráva žaludků. Pokud mu odpovíš správně, vezme tě do služby.");
        string cast13_hadanka = Console.ReadLine();

        if (cast13_hadanka == "4" || cast13_hadanka == "čtyři")
        {
            penize += 3;

            Console.WriteLine("Výborně, dostal jsi od hospodáře 3 dolary a máš tedy " + penize + " dolarů.");
            Console.ReadLine();
        }
    }
    else if (cast13_vypomoc == "2")
    {
        cast13_konec = 1;
    }
}

int charita_vztah = 0;

if (cast13_vypomoc == "1")
{
    int cast14_konec = 0;
    while (cast14_konec != 1)
    {
        Console.Clear();
        Console.WriteLine("Máš " + penize + " dolarů");
        Console.WriteLine(kola + ". Kolo");
        Console.WriteLine("Máš " + stamina + " staminy");

        Console.WriteLine("\nPo náročné práci u hospodáře jdeš dál městem a potkáš majitelku místní charity, která tě poprosí o bezplatnou pomoc. Pomůžeš jí?");
        Console.WriteLine("1. Ano");
        Console.WriteLine("2. Ne");
        string cast14_charita = Console.ReadLine();

        if (cast14_charita == "1")
        {
            cast14_konec = 1;

            if (stamina < 50)
                {
                    kola++;
                }
            stamina -= 10;
            kola++;
            karma += 1;

            charita_vztah = 50;

            int charita_konec = 0;
            while (charita_konec != 1)
            {
                Console.Clear();
                Console.WriteLine("Paní ti poděkuje a zeptá se, kam máš namířeno. Ty jí popravdě odpovíš a ona ti položí další otázku, jestli nebudeš chtít jí pomoc s charitou v dalších městech. Pomůžeš jí?");
                Console.WriteLine("1. Ano");
                Console.WriteLine("2. Ne");
                string charita_pomoc = Console.ReadLine();

                if (charita_pomoc == "1")
                {
                    charita_konec = 1;
                    charita_vztah = 100;
                }
                else if (charita_pomoc == "2")
                {
                    charita_konec = 1;
                }
            }
            
        }
        else if (cast14_charita == "2")
        {
            cast14_konec = 1;

            karma -= 1;

            Console.Clear();
            Console.WriteLine("Bohužel jsi paní odmítl a odcházíš.");
            Console.ReadLine();
        }
    }
}
else
{
    int cast14_konec = 0;
    while (cast14_konec != 1)
    {
        Console.Clear();
        Console.WriteLine("Máš " + penize + " dolarů");
        Console.WriteLine(kola + ". Kolo");
        Console.WriteLine("Máš " + stamina + " staminy");

        Console.WriteLine("\nPo odmítnutí hospodáře jdeš dál městem a potkáš majitelku místní charity, která tě poprosí o bezplatnou pomoc. Pomůžeš jí?");
        Console.WriteLine("1. Ano");
        Console.WriteLine("2. Ne");
        string cast14_charita = Console.ReadLine();

        if (cast14_charita == "1")
        {
            cast14_konec = 1;

            if (stamina < 50)
            {
                kola++;
            }
            stamina -= 10;
            kola++;
            karma += 1;

            charita_vztah = 50;

            int charita_konec = 0;
            while (charita_konec != 1)
            {
                Console.Clear();
                Console.WriteLine("Paní ti poděkuje a zeptá se, kam máš namířeno. Ty jí popravdě odpovíš a ona ti položí další otázku, jestli nebudeš chtít jí pomoc s charitou v dalších městech. Pomůžeš jí?");
                Console.WriteLine("1. Ano");
                Console.WriteLine("2. Ne");

                string charita_pomoc = Console.ReadLine();

                if (charita_pomoc == "1")
                {
                    charita_konec = 1;
                    charita_vztah = 100;
                }
                else if (charita_pomoc == "2")
                {
                    charita_konec = 1;
                }
            }
        }
        else if (cast14_charita == "2")
        {
            cast14_konec = 1;

            karma -= 1;

            Console.Clear();
            Console.WriteLine("Bohužel jsi paní odmítl a odcházíš.");
            Console.ReadLine();
        }
    }
}

int cast_15_konec = 0;
while (cast_15_konec != 1)
{
    Console.Clear();
    Console.WriteLine("Máš " + penize + " dolarů");
    Console.WriteLine(kola + ". Kolo");
    Console.WriteLine("Máš " + stamina + " staminy");

    Console.WriteLine("\nProcházíš kolem místní ubytovny. Chceš si zde za poplatek odpočinout, nebo přivydělat, nebo ji jen minout a pokračovat dál?");
    Console.WriteLine("1. Odpočinout si (2 dolary)");
    Console.WriteLine("2. Přivydělat si (4 dolary)");
    Console.WriteLine("3. Pouze minout a pokračovat dál");

    string cast_15_ubytovna = Console.ReadLine();

    if (cast_15_ubytovna == "1")
    {
        if (penize >= 2)
        {
            cast_15_konec = 1;
            penize -= 2;
            stamina += 50;

            kola += 2;

            Console.Clear();
            Console.WriteLine("V ubytovně sis odpočinul a příští den pokračuješ dál v cestě.");
            Console.ReadLine();
        }
        else
        {
            Console.WriteLine("Bohužel nemáš dostatek peněz");
            Console.ReadLine();
        }
        
    }
    else if (cast_15_ubytovna == "2")
    {
        cast_15_konec = 1;
        penize += 4;

        if (stamina < 50)
        {
            kola += 2;
        }
        stamina -= 10;
        kola += 2;

        Console.Clear();
        Console.WriteLine("V ubytovně sis vydělal 4 dolary a máš tedy u sebe " + penize + " dolarů.");
        Console.ReadLine();
    }
    else if (cast_15_ubytovna == "3")
    {
        cast_15_konec = 1;

        if (stamina < 50)
        {
            kola++;
        }
        stamina -= 10;
        kola++;

        Console.Clear();
        Console.WriteLine("Ubytovnu pouze mineš a pokračuješ dál ve své cestě.");
        Console.ReadLine();
    }
}

int cast_16_konec = 0;
while (cast_16_konec != 1)
{
    Console.Clear();
    Console.WriteLine("Máš " + penize + " dolarů");
    Console.WriteLine(kola + ". Kolo");
    Console.WriteLine("Máš " + stamina + " staminy");

    Console.WriteLine("\nMineš poštu a v tu chvíli tě zasáhne silný stesk po tvé rodině. Chceš jim za poplatek poslat dopis, že jsi v pořádku?");
    Console.WriteLine("1. Ano (2 dolary, přidání staminy)");
    Console.WriteLine("2. Ne");

    string cast_16_posta = Console.ReadLine();

    if (cast_16_posta == "1")
    {
        if (penize >= 2)
        {
            cast_16_konec = 1;
            penize -= 2;
            stamina += 50;
            kola++;
            Console.Clear();
            Console.WriteLine("Za poštu si zaplatil 2 dolary a máš u sebe " + penize + " dolarů");
            Console.ReadLine();
        }
        else
        {
            Console.WriteLine("Bohužel nemáš dostatek peněz");
            Console.ReadLine();
        }
    }
    else if (cast_16_posta == "2")
    {
        cast_16_konec = 1;
        
        Console.Clear();
        Console.WriteLine("Poštu si pouze minul a pokračuješ dál");
        Console.ReadLine();
    }
}

string cast_17_1_les = "";
int cast_17_1_konec = 0;
while (cast_17_1_konec != 1)
{
    Console.Clear();
    Console.WriteLine("Máš " + penize + " dolarů");
    Console.WriteLine(kola + ". Kolo");
    Console.WriteLine("Máš " + stamina + " staminy");

    Console.WriteLine("\nMěsto necháváš za sebou, ale je tu další překážka v podobě lesa. Povídá se, že v lese žijí loupežníci. Chceš les obejít, nebo ho projít skrz?");
    Console.WriteLine("1. Les obejít (3 kola)");
    Console.WriteLine("2. Projít les skrz (1 kolo)");

    cast_17_1_les = Console.ReadLine();

    if (cast_17_1_les == "1")
    {
        cast_17_1_konec = 1;
        if (stamina < 50)
        {
            kola += 3;
        }
        stamina -= 10;
        kola += 3;
    }
    else if (cast_17_1_les == "2")
    {
        cast_17_1_konec = 1;
        if (stamina < 50)
        {
            kola++;
        }
        stamina -= 10;
        kola++;
    }
}

int cast_17_2_konec = 0;
while (cast_17_2_konec != 1)
{
    if (cast_17_1_les == "2")
    {
        if (vec1 == "7" || vec2 == "7" || vec3 == "7" || vec4 == "7")
        {
            Console.Clear();
            Console.WriteLine("Máš " + penize + " dolarů");
            Console.WriteLine(kola + ". Kolo");
            Console.WriteLine("Máš " + stamina + " staminy");

            Console.WriteLine("\nJdeš lesem a začíná se stmívat. Chceš si zde udělat táborák a odpočinout si, nebo si pouze odpočinout, nebo můžeš pokračovat v cestě? Pozor, pomocí táboráku tě můžou najít loupežníci.");
            Console.WriteLine("1. Udělat si táborák a odpočinout si (+ 60 staminy)");
            Console.WriteLine("2. Odpočinout si (+ 30 staminy)");
            Console.WriteLine("3. Pokračovat v cestě");

            string cast_17_2_taborak = Console.ReadLine();

            if (cast_17_2_taborak == "1")
            {
                cast_17_2_konec = 1;
                stamina += 60;
                kola += 2;

                Random prepadeni_loupezniky = new Random();
                int prepadeni_loupezniky1 = prepadeni_loupezniky.Next(1, 100);

                if (prepadeni_loupezniky1 < 50)
                {
                    Console.Clear();
                    if (penize > 5)
                    {
                        penize -= 3;
                        Console.WriteLine("Po probuzení vidíš, že tě někdo okradl o 3 dolary a máš u sebe " + penize + " dolarů");
                        Console.ReadLine();
                    }
                    else if (penize > 0)
                    {
                        penize -= 1;
                        Console.WriteLine("Po probuzení vidíš, že tě někdo okradl o 1 dolar a máš u sebe " + penize + " dolarů");
                    }
                }
            }
            else if (cast_17_2_taborak == "2")
            {
                cast_17_2_konec = 1;
                stamina += 30;
                kola += 2;

                Console.Clear();
                Console.WriteLine("V lese si odpočineš a ráno pokojně pokračuješ v cestě");
                Console.ReadLine();
            }
            else if (cast_17_2_taborak == "3")
            {
                cast_17_2_konec = 1;
                if (stamina < 50)
                {
                    kola++;
                }
                stamina -= 10;
                kola++;

                Console.Clear();
                Console.WriteLine("Les rychle projdeš a nezastavuješ se");
                Console.ReadLine();
            }
        }
        else
        {
            Console.Clear();
            Console.WriteLine("Máš " + penize + " dolarů");
            Console.WriteLine(kola + ". Kolo");
            Console.WriteLine("Máš " + stamina + " staminy");

            Console.WriteLine("\nJdeš lesem a začíná se stmívat. Bohužel nemáš u sebe sirky, a tak nemůžeš si udělat táborák. Chceš si zde odpočinout, nebo můžeš pokračovat v cestě?");
            Console.WriteLine("1. Odpočinout si (+ 30 staminy)");
            Console.WriteLine("2. Pokračovat v cestě");

            string cast_17_2_taborak = Console.ReadLine();

            if (cast_17_2_taborak == "1")
            {
                cast_17_2_konec = 1;

                stamina += 30;
                kola += 2;

                Console.Clear();
                Console.WriteLine("V lese si odpočineš a ráno pokojně pokračuješ v cestě");
                Console.ReadLine();
            }
            else if (cast_17_2_taborak == "2")
            {
                cast_17_2_konec = 1;

                if (stamina < 50)
                {
                    kola++;
                }
                stamina -= 10;
                kola++;

                Console.Clear();
                Console.WriteLine("Les rychle projdeš a nezastavuješ se");
                Console.ReadLine();
            }
        }
    }
    else
    {
        if (vec1 == "7" || vec2 == "7" || vec3 == "7" || vec4 == "7")
        {
            Console.Clear();
            Console.WriteLine("Máš " + penize + " dolarů");
            Console.WriteLine(kola + ". Kolo");
            Console.WriteLine("Máš " + stamina + " staminy");

            Console.WriteLine("\nObcházíš les a začíná se stmívat. Chceš si zde udělat táborák a odpočinout si, nebo můžeš pokračovat v cestě?");
            Console.WriteLine("1. Udělat si táborák a odpočinout si (+ 50 staminy)");
            Console.WriteLine("2. Pokračovat v cestě");

            string cast_17_2_taborak = Console.ReadLine();

            if (cast_17_2_taborak == "1")
            {
                cast_17_2_konec = 1;
                stamina += 50;
                kola += 2;

                Console.Clear();
                Console.WriteLine("Uděláš si táborák a odpočineš si");
                Console.ReadLine();
            }
            else if (cast_17_2_taborak == "2")
            {
                cast_17_2_konec = 1;

                if (stamina < 50)
                {
                    kola++;
                }
                stamina -= 10;
                kola++;

                Console.Clear();
                Console.WriteLine("Pokračuješ dál v cestě");
                Console.ReadLine();
            }
        }
        else
        {
            Console.Clear();
            Console.WriteLine("Máš " + penize + " dolarů");
            Console.WriteLine(kola + ". Kolo");
            Console.WriteLine("Máš " + stamina + " staminy");

            Console.WriteLine("\nObcházíš les a začíná se stmívat. Bohužel u sebe nemáš sirky, a tak si nemůžeš udělat táborák. Chceš si zde odpočinout, nebo můžeš pokračovat v cestě?");
            Console.WriteLine("1. Odpočinout si (+ 20 staminy)");
            Console.WriteLine("2. Pokračovat v cestě");

            string cast_17_2_taborak = Console.ReadLine();

            if (cast_17_2_taborak == "1")
            {
                cast_17_2_konec = 1;
                stamina += 20;
                kola += 2;

                Console.Clear();
                Console.WriteLine("Odpočineš si a ráno pokračuješ v cestě");
                Console.ReadLine();
            }
            else if (cast_17_2_taborak == "2")
            {
                cast_17_2_konec = 1;

                if (stamina < 50)
                {
                    kola++;
                }
                stamina -= 10;
                kola++;

                Console.Clear();
                Console.WriteLine("Pokračuuješ dál v cestě za pokladem");
                Console.ReadLine();
            }
        }
    }
}

if (koupeni_mapy == "2" || koupeni_mapy2 == "2")
{
    int cast_18_konec = 0;
    while (cast_18_konec != 1)
    {
        Console.Clear();
        Console.WriteLine("Máš " + penize + " dolarů");
        Console.WriteLine(kola + ". Kolo");
        Console.WriteLine("Máš " + stamina + " staminy");

        Console.WriteLine("\nJdeš dál, ale stále se přesně nedokážeš zorientovat v mapě. Najednou se potkáš s cestovatelem. Řekneš si, že by mohl vědět více o mapách než ty. Zeptáš se ho, jestli by ti nemohl poradit. On se na mapu dlouze podívá a řekne, že znal podobného člověka, jako jsi ty. Měl prý u sebe stejnou mapu a poklad nikdy nenašel. Dále ti řekne, že se povídá mezi poutníky, že existuje přesnější mapa, kterou u sebe shodou okolností má. Poutník ti ji nabízí za 9 dolarů. Koupíš si ji, nebo si u něho nejdřív na ni vyděláš?");
        Console.WriteLine("1. Ano");
        Console.WriteLine("2. Ano a vydělání 9 dolarů (9 kol)");

        string cast_18_mapa = Console.ReadLine();

        if (cast_18_mapa == "1")
        {
            if (penize >= 9)
            {
                koupeni_mapy = "3";
                cast_18_konec = 1;

                if (stamina < 50)
                {
                    kola++;
                }
                stamina -= 10;
                kola++;

                penize -= 9;

                Console.Clear();
                Console.WriteLine("Výborně, zakoupil sis mapu od cestovatele za 9 dolarů a máš u sebe " + penize + " dolarů");
                Console.ReadLine();
            }
            else
            {
                Console.WriteLine("Bohužel nemáš dostatek peněz");
                Console.ReadLine();
            }
        }
        else if (cast_18_mapa == "2")
        {
            koupeni_mapy = "3";
            cast_18_konec = 1;

            if (stamina < 50)
            {
                kola += 9;
            }
            stamina -= 10;
            kola += 9;

            Console.Clear();
            Console.WriteLine("Výborně, po těžké práci sis vysloužil mapu od cestovatele");
            Console.ReadLine();
        }
    }
}

int cast_19_konec = 0;
while (cast_19_konec != 1)
{
    Console.Clear();
    Console.WriteLine("Máš " + penize + " dolarů");
    Console.WriteLine(kola + ". Kolo");
    Console.WriteLine("Máš " + stamina + " staminy");

    Console.WriteLine("\nJdeš dál a najednou v dálce vidíš farmáře, který opravuje střechu. Přijdeš k němu a on se tě zeptá, jestli mu nepomůžeš. Pomůžeš farmáři?");
    Console.WriteLine("1. Ano (vydělání 1 dolar a zvýšení karmy)");
    Console.WriteLine("2. Ne");

    string cast_19_farmar = Console.ReadLine();

    if (cast_19_farmar == "1")
    {
        cast_19_konec = 1;

        if (stamina < 50)
        {
            kola++;
        }
        stamina -= 10;
        kola++;
        karma++;

        Console.Clear();
        Console.WriteLine("Napiš jeden typ obilí (všechny písmena malá, s diakritikou)");

        string cast_19_hadanka = Console.ReadLine();

        if (cast_19_hadanka == "žito" || cast_19_hadanka == "oves" || cast_19_hadanka == "pšenice" || cast_19_hadanka == "ječmen")
        {
            penize += 1;
            Console.WriteLine("Výborně, získáváš 1 dolar a máš u sebe " + penize + " dolarů");
            Console.ReadLine();
        }
        else
        {
            Console.WriteLine("Bohužel špatně");
            Console.ReadLine();
        }
    }
    else if (cast_19_farmar == "2")
    {
        cast_19_konec = 1;

        Console.Clear();
        Console.WriteLine("Farmáře si nevšímáš a pokračuješ v cestě");
        Console.ReadLine();
    }
}

int cast_20_konec = 0;
while (cast_20_konec != 1)
{
    Console.Clear();
    Console.WriteLine("Máš " + penize + " dolarů");
    Console.WriteLine(kola + ". Kolo");
    Console.WriteLine("Máš " + stamina + " staminy");

    Console.WriteLine("\nPo dlouhé chvíli vidíš před sebou další město. Vidíš pouličního sázkaře, u kterého si můžeš vsadit, nebo si přivydělat u místního kováře. Jak se rozhodneš?");
    Console.WriteLine("1. Zkusit štěstí u pouličního sázkaře");
    Console.WriteLine("2. Přivydělat si u místního kováře (3 dolary)");

    string cast_20_vydelavani = Console.ReadLine();

    if (cast_20_vydelavani == "1")
    {
        cast_20_konec = 1;

        if (stamina < 50)
        {
            kola++;
        }
        stamina -= 10;
        kola++;

        int cast_20_sazkar_konec = 0;
        while (cast_20_sazkar_konec != 1)
        {
            Console.Clear();
            Console.WriteLine("Máš " + penize + " dolarů");
            Console.WriteLine(kola + ". Kolo");
            Console.WriteLine("Máš " + stamina + " staminy");

            Console.WriteLine("\nKolik si chceš vsadit? (Používej pouze číslice)");
            int sazka = int.Parse(Console.ReadLine());

            if (penize >= sazka)
            {
                cast_20_sazkar_konec = 1;

                int stesti1 = karma * 10 + 40;

                Random pravdepodobnost = new Random();
                int pravdepodobnost1 = pravdepodobnost.Next(1, 100);

                if (stesti1 >= pravdepodobnost1)
                {
                    penize = penize + sazka;
                    karma--;
                    Console.Clear();
                    Console.WriteLine("Výborně, vyhrál jsi " + sazka + " dolarů a máš u sebe " + penize + " dolarů");
                    Console.ReadLine();
                }
            }
            else
            {
                Console.WriteLine("Bohužel nemáš dostatek peněz");
                Console.ReadLine();
            }
        }
    }
    else if (cast_20_vydelavani == "2")
    {
        cast_20_konec = 1;

        if (stamina < 50)
        {
            kola++;
        }
        stamina -= 10;
        kola++;

        Console.Clear();
        Console.WriteLine("Napiš chemickou značku železa");

        string cast_20_hadanka = Console.ReadLine();

        if (cast_20_hadanka == "Fe")
        {
            penize += 3;
            Console.WriteLine("Výborně, získáváš 3 dolary a máš u sebe " + penize + " dolarů");
            Console.ReadLine();
        }
        else
        {
            Console.WriteLine("Bohužel špatně");
            Console.ReadLine();
        }
    }
}

int cast_21_konec = 0;
while (cast_21_konec != 1)
{
    Console.Clear();
    Console.WriteLine("Máš " + penize + " dolarů");
    Console.WriteLine(kola + ". Kolo");
    Console.WriteLine("Máš " + stamina + " staminy");

    Console.WriteLine("\nPoněvadž máš oblečení špinavé, je možnost si ve městě za poplatek oblečení vyprat a odpočinout si. Jak se rozhodneš?");
    Console.WriteLine("1. Nechat si vyprat oblečení a odpočinout si (5 dolarů)");
    Console.WriteLine("2. Pokračovat v cestě");

    string cast_21_odpocinek = Console.ReadLine();

    if (cast_21_odpocinek == "1")
    {
        if (penize >= 5)
        {
            cast_21_konec = 1;
            kola += 2;
            stamina += 70;
            penize -= 5;
            Console.Clear();
            Console.WriteLine("Ve městě si necháš vyprat oblečení a odpočineš si za poplatek. Máš u sebe " + penize + " dolarů.");
            Console.ReadLine();
        }
        else
        {
            Console.WriteLine("Bohužel nemáš dostatek peněz");
            Console.ReadLine();
        }
    }
    else if (cast_21_odpocinek == "2")
    {
        cast_21_konec = 1;
        if (stamina < 50)
        {
            kola++;
        }
        stamina -= 10;
        kola++;
        Console.Clear();
        Console.WriteLine("Pokračuješ v cestě.");
        Console.ReadLine();
    }
}

if (charita_vztah == 100)
{
    int charita2_konec = 0;
    while (charita2_konec != 1)
    {
        Console.Clear();
        Console.WriteLine("Máš " + penize + " dolarů");
        Console.WriteLine(kola + ". Kolo");
        Console.WriteLine("Máš " + stamina + " staminy");

        Console.WriteLine("\nChceš ve městě udělat reklamu charitě?");
        Console.WriteLine("1. Ano");
        Console.WriteLine("2. Ne");
        string charita2_pomoc = Console.ReadLine();

        if (charita2_pomoc == "1")
        {
            charita2_konec = 1;
            if (stamina < 50)
            {
                kola++;
            }
            stamina -= 10;
            kola++;

            charita_vztah += 50;
            karma += 2;

            Console.Clear();
            Console.WriteLine("Po nějaké době přemlouvání lidí se rozhodneš pokračovat dál.");
            Console.ReadLine();
        }
        else if (charita2_pomoc == "2")
        {
            charita2_konec = 1;
            charita_vztah -= 50;
        }
    }
}

int cast_22_konec = 0;
while (cast_22_konec != 1)
{
    Console.Clear();
    Console.WriteLine("Máš " + penize + " dolarů");
    Console.WriteLine(kola + ". Kolo");
    Console.WriteLine("Máš " + stamina + " staminy");

    Console.WriteLine("\nVe městě ale narazíš ještě na kočího, který by tě mohl za poplatek převézt rychleji na místo, které mu řekneš. Chceš se svézt v kočáře, nebo pokračovat pěšky?");
    Console.WriteLine("1. Svézt se v kočáře (3 dolary)");
    Console.WriteLine("2. Pokračovat v cestě (3 kola)");

    string cast_22_kocar = Console.ReadLine();

    if (cast_22_kocar == "1")
    {
        if (penize >= 3)
        {
            cast_22_konec = 1;
            penize -= 3;
            kola++;
            Console.Clear();
            Console.WriteLine("Poté, co jsi přijel, ti zbylo " + penize + " dolarů.");
            Console.ReadLine();
        }
        else
        {
            Console.WriteLine("Bohužel nemáš dostatek peněz.");
            Console.ReadLine();
        }
    }
    else if (cast_22_kocar == "2")
    {
        cast_22_konec = 1;
        
        if (stamina < 50)
        {
            kola += 3;
        }
        stamina -= 10;
        kola += 3;

        Console.Clear();
        Console.WriteLine("Pokračuješ dál pěšky.");
        Console.ReadLine();
    }
}
string cast_23_loupeznici = "";

int cast_23_konec = 0;
while (cast_23_konec != 1)
{
    Console.Clear();
    Console.WriteLine("Máš " + penize + " dolarů");
    Console.WriteLine(kola + ". Kolo");
    Console.WriteLine("Máš " + stamina + " staminy");

    if (zbran == "2" || zbran == "3")
    {
        Console.WriteLine("\nPokračuješ dále v cestě za pokladem a najednou uvidíš tábor loupežníků. Loupežníci na tebe vyskočí pouze s noži. Ty instinktivně vytáhneš zbraň. Náčelník loupežníků rychle pochopí, kdo by tento souboj vyhrál, a tak ti nabídne možnost se k nim přidat a něco si možná přivydělat. Budeš se chtít k loupežníkům přidat, nebo ne?");
        Console.WriteLine("1. Ano");
        Console.WriteLine("2. Ne");

        cast_23_loupeznici = Console.ReadLine();

        if (cast_23_loupeznici == "1")
        {
            cast_23_konec = 1;
            karma--;

            if (stamina < 50)
            {
                kola++;
            }
            stamina -= 10;
            kola++;

            Console.Clear();
            Console.WriteLine("Přidáváš se k loupežníkům.");
            Console.ReadLine();
        }
        else if (cast_23_loupeznici == "2")
        {
            cast_23_konec = 1;

            if (stamina < 50)
            {
                kola++;
            }
            stamina -= 10;
            kola++;

            Console.Clear();
            Console.WriteLine("Loupežníci tě nechali v klidu odejít.");
            Console.ReadLine();
        }
    }
    else if (vec1 == "4" || vec2 == "4" || vec3 == "4" || vec4 == "4")
    {
        Console.WriteLine("\nPokračuješ dále v cestě za pokladem a najednou uvidíš tábor loupežníků. Loupežníci na tebe vyskočí pouze s noži. Naštěstí máš u sebe nůž taky. Chceš s loupežníky bojovat, nebo jim dáš své peníze dobrovolně?");
        Console.WriteLine("1. S loupežníky bojovat");
        Console.WriteLine("2. Dát jim své peníze dobrovolně");

        string cast_23_loupeznici1 = Console.ReadLine();

        if (cast_23_loupeznici1 == "1")
        {
            cast_23_konec = 1;
            
            if (stamina < 50)
            {
                kola++;
            }
            stamina -= 10;
            kola++;

            int stesti2 = karma * 10 + 50;

            Random pravdepodobnost = new Random();
            int pravdepodobnost1 = pravdepodobnost.Next(1, 100);

            if (stesti2 >= pravdepodobnost1)
            {
                Console.Clear();
                Console.WriteLine("Výborně, loupežníky si přemohl.");
                Console.ReadLine();
            }
            else
            {
                if (penize > 5)
                {
                    penize -= 3;

                    if (stamina < 50)
                    {
                        kola++;
                    }
                    stamina -= 10;
                    kola++;

                    Console.Clear();
                    Console.WriteLine("Bohužel si loupežníky nepřemohl a oni tě okradli o 3 dolary, a tudíž máš u sebe " + penize + " dolarů.");
                    Console.ReadLine();
                }
                else if (penize > 0)
                {
                    penize -= 1;

                    if (stamina < 50)
                    {
                        kola++;
                    }
                    stamina -= 10;
                    kola++;

                    Console.Clear();
                    Console.WriteLine("Bohužel si loupežníky nepřemohl a oni tě okradli o 1 dolar, a tudíž máš u sebe " + penize + " dolarů.");
                    Console.ReadLine();
                }
                else
                {
                    if (stamina < 50)
                    {
                        kola++;
                    }
                    stamina -= 30;
                    kola++;

                    Console.Clear();
                    Console.WriteLine("Bohužel si loupežníky nepřemohl a poněvadž nemáš žádné peníze, tak jsi přišel o 30 staminy.");
                    Console.ReadLine();
                }
            }
        }
        else if (cast_23_loupeznici1 == "2")
        {
            cast_23_konec = 1;
            if (stamina < 50)
                {
                    kola++;
                }
            stamina -= 10;
            kola++;

            if (penize > 0)
            {
                penize -= 1;

                Console.Clear();
                Console.WriteLine("Loupežníkům jsi dal 1 dolar a oni tě nechali jít dál.");
                Console.ReadLine();
            }
            else
            {
                stamina -= 20;

                Console.Clear();
                Console.WriteLine("Poněvadž u sebe nemáš žádné peníze, tak jsi přišel o 20 staminy.");
            }
        }
    }
    else
    {
        cast_23_konec = 1;

        Console.WriteLine("\nPokračuješ dále v cestě za pokladem a najednou uvidíš tábor loupežníků. Loupežníci na tebe vyskočí pouze s noži. Bohužel u sebe nemáš žádnou zbraň, a tak musíš dát loupežníkům část peněz.");
        Console.ReadLine();

        if (penize > 5)
        {
            penize -= 3;

            if (stamina < 50)
            {
                kola++;
            }
            stamina -= 10;
            kola++;

            Console.Clear();
            Console.WriteLine("Bohužel si loupežníky nepřemohl a oni tě okradli o 3 dolary, a tudíž máš u sebe " + penize + " dolarů.");
            Console.ReadLine();
        }
        else if (penize > 0)
        {
            penize -= 1;

            if (stamina < 50)
            {
                kola++;
            }
            stamina -= 10;
            kola++;

            Console.Clear();
            Console.WriteLine("Bohužel si loupežníky nepřemohl a oni tě okradli o 1 dolar, a tudíž máš u sebe " + penize + " dolarů.");
            Console.ReadLine();
        }
        else
        {
            if (stamina < 50)
            {
                kola++;
            }
            stamina -= 30;
            kola++;

            Console.Clear();
            Console.WriteLine("Bohužel si loupežníky nepřemohl a poněvadž nemáš žádné peníze, tak jsi přišel o 30 staminy.");
            Console.ReadLine();
        }
    }
}

int cast_24_konec = 0;
while (cast_24_konec != 1)
{
    Console.Clear();
    Console.WriteLine("Máš " + penize + " dolarů");
    Console.WriteLine(kola + ". Kolo");
    Console.WriteLine("Máš " + stamina + " staminy");

    if (cast_23_loupeznici == "1")
    {

        if (stamina < 50)
        {
            kola++;
        }
        stamina -= 10;
        kola++;


        Console.WriteLine("\nPoté, co jsi s loupežníky navázal spolupráci, šli okrádat nevinné lidi. Chceš se k vykrádání přidat?");
        Console.WriteLine("1. Ano");
        Console.WriteLine("2. Ne");

        string cast_24_vykradani = Console.ReadLine();

        if (cast_24_vykradani == "1")
        {
            karma -= 3;
            cast_24_konec = 1;
            
            if (stamina < 50)
            {
                kola++;
            }
            stamina -= 10;
            kola++;

            int cast_24_1_konec = 0;
            while (cast_24_1_konec != 1)
            {
                Console.Clear();
                Console.WriteLine("Ukrýváš se společně se svými novými kamarády v keři. Najednou uvidíte obchodníka. Když se k vám přiblíží, vyskočíte z keře a namíříte na něj zbraně. Ovšem obchodník má u sebe kamaráda a oba mají zbraně. Pokusíš se je okrást, nebo radši utečeš?");
                Console.WriteLine("1. Pokusit si je okrást");
                Console.WriteLine("2. Utéct");

                string cast_24_1_prestrelka = Console.ReadLine();

                if (cast_24_1_prestrelka == "1")
                {
                    karma--;
                    cast_24_1_konec = 1;
                    Console.Clear();
                    Console.WriteLine("Kdy začala první světová válka?");
                    Console.WriteLine("a) 6. 4. 2014");
                    Console.WriteLine("b) 11. 11. 1914");
                    Console.WriteLine("c) 28. 7. 1914");
                    Console.WriteLine("d) 1. 9. 1914");

                    string cast_24_1_hadanka = Console.ReadLine();

                    if (cast_24_1_hadanka == "c" || cast_24_1_hadanka == "C")
                    {
                        Random plus_naboje = new Random();
                        int plus_naboje1 = plus_naboje.Next(1, 10);
                        penize += 5;
                        naboje = naboje + plus_naboje1;

                        Console.WriteLine("\nVýborně, správná odpověď. Obchodníci utekli a nechali ve voze " + plus_naboje1 + " nábojů a 5 dolarů.");
                        Console.ReadLine();
                    }
                    else
                    {
                        naboje = 0;
                        
                        if (stamina < 50)
                        {
                            kola++;
                        }
                        stamina -= 30;
                        kola++;

                        Console.WriteLine("\nBohužel špatná odpověď. Přišel jsi o všehcny náboje, ale naštěstí se ti povedlo utéct.");
                        Console.ReadLine();
                    }
                }
                else if (cast_24_1_prestrelka == "2")
                {
                    cast_24_1_konec = 1;
                    if (stamina < 50)
                    {
                        kola++;
                    }
                    stamina -= 10;
                    kola++;

                    Console.Clear();
                    Console.WriteLine("Podařilo se ti utéct.");
                    Console.ReadLine();
                }
            }
        }
        else if (cast_24_vykradani == "2")
        {
            cast_24_konec = 1;

            if (stamina < 50)
            {
                kola++;
            }
            stamina += 20;
            kola++;

            int cast_24_2_tabor_konec = 0;
            while (cast_24_2_tabor_konec != 1)
            {
                Console.Clear();
                Console.WriteLine("Máš " + penize + " dolarů");
                Console.WriteLine(kola + ". Kolo");
                Console.WriteLine("Máš " + stamina + " staminy");

                Console.WriteLine("\nV táboře si odpočineš a napadne tě plán, že bys neopatrné loupežníky mohl okrást. Budeš chtít loupežníkův tábor vykrást, nebo budeš pokračovat v cestě za pokladem?");
                Console.WriteLine("1. Tábor vykrást");
                Console.WriteLine("2. Pokračovat v cestě za pokladem");

                string cast_24_2_tabor = Console.ReadLine();

                if (cast_24_2_tabor == "1")
                {
                    cast_24_2_tabor_konec = 1;

                    karma--;
                    if (stamina < 50)
                    {
                        kola += 2;
                    }
                    stamina -= 10;
                    kola += 2;

                    Random okradeni = new Random();
                    int okradeni1 = okradeni.Next(1, 4);

                    penize = penize + okradeni1;

                    Console.Clear();
                    Console.WriteLine("Tábor si úspěšně vykradl a získal jsi " + okradeni1 + " dolarů.");
                    Console.ReadLine();
                }
                else if (cast_24_2_tabor == "2")
                {
                    cast_24_2_tabor_konec = 1;

                    if (stamina < 50)
                    {
                        kola++;
                    }
                    stamina -= 10;
                    kola++;
                    
                    Console.Clear();
                    Console.WriteLine("Tábor opouštíš a pokračuješ v cestě.");
                    Console.ReadLine();
                }
            }
        }
    }
    else
    {
        Console.Clear();
        Console.WriteLine("Máš " + penize + " dolarů");
        Console.WriteLine(kola + ". Kolo");
        Console.WriteLine("Máš " + stamina + " staminy");

        Console.WriteLine("\nPo děsivém setkání s loupežníky pokračuješ dál a potkáš v lese dřevorubce, který ti nabídne si u něho prací přivydělat. Chceš si u dřevorubce přivydělat?");
        Console.WriteLine("1. Ano (3 dolary)");
        Console.WriteLine("2. Ne");

        string cast_24_2_vydelavani = Console.ReadLine();

        if (cast_24_2_vydelavani == "1")
        {
            cast_24_konec = 1;

            if (stamina < 50)
            {
                kola++;
            }
            stamina -= 10;
            kola++;


            Console.Clear();
            Console.WriteLine("Jaké typy lesů v čr jsou nejčastější?");
            Console.WriteLine("a) Jehličnaté");
            Console.WriteLine("b) Listnaté");
            Console.WriteLine("c) Smíšené");
            Console.WriteLine("d) Jsou ve stejném poměru");

            string cast_24_2_hadanka = Console.ReadLine();

            if (cast_24_2_hadanka == "a" || cast_24_2_hadanka == "A")
            {
                penize += 3;

                Console.WriteLine("Správně, získáváš 3 dolary a máš u sebe " + penize + " dolarů.");
                Console.ReadLine();
            }
            else
            {
                Console.WriteLine("Bohužel špatně.");
                Console.ReadLine();
            }
        }
        else if (cast_24_2_vydelavani == "2")
        {
            cast_24_konec = 1;

            Console.Clear();
            Console.WriteLine("Dřevorubce pouze mineš a pokračuješ dál.");
            Console.ReadLine();
        }
    }
}

Console.Clear();
Console.WriteLine("Máš " + penize + " dolarů");
Console.WriteLine(kola + ". Kolo");
Console.WriteLine("Máš " + stamina + " staminy");

Console.WriteLine("\nPokračuješ dále a naneštěstí vidíš před sebou rozsáhlou bažinu, přes kterou musíš jít, poněvadž podle mapy si poklad ukrývá v téhle bažině. Musíš dávat velký pozor, aby ses neutopil.");
Console.ReadLine();

Console.Clear();
Console.WriteLine("Jaký je výsledek tohoto příkladu?");
Console.WriteLine("16 + 8 * 3 - (24 - 10)");

string cast_25_hadanka = Console.ReadLine();

if (cast_25_hadanka == "26")
{
    if (stamina < 50)
    {
        kola++;
    }
    stamina -= 10;
    kola++;

    Console.WriteLine("\nVýborně, dostal ses úspěšně přes část bažiny.");
    Console.ReadLine();
}
else
{
    if (stamina < 50)
    {
        kola += 4;
    }
    stamina -= 10;
    kola += 4;

    Console.WriteLine("\nBohužel špatně, ale přes bažinu ses nakonec po dlouhé době dostal.");
    Console.ReadLine();
}

Random konecne_kolo = new Random();
int konecne_kolo1 = konecne_kolo.Next(33, 38);

int uspesne_premlouvani = 0;

int cast_26_konec = 0;
while (cast_26_konec != 1)
{
    Console.Clear();
    Console.WriteLine("Máš " + penize + " dolarů");
    Console.WriteLine(kola + ". Kolo");
    Console.WriteLine("Máš " + stamina + " staminy");

    if (kola > konecne_kolo1)
    {
        Console.WriteLine("\nPodle mapy by měl být poklad blízko. Dojdeš k místu, kde je na mapě křížek, ale je tam vykopaná díra a vedle ní lopata. Bohužel poklad našel někdo před tebou.");
        string cheat = Console.ReadLine();

        if (cheat == "MikeEis")
        {
            kola = 20;
        }
        else
        {
            cast_26_konec = 1;

            Console.Clear();
            Console.WriteLine("Tady tvá cesta bohužel neúspěšně končí. Vracíš se domů a rodina tě sice ráda vidí, ale ty jsi zklamán, že jsi neuspěl.");
            
            int stesti3 = karma * 10 + 40;

            Console.WriteLine("\nKola: " + kola);
            Console.WriteLine("Stamina: " + stamina);
            Console.WriteLine("Peníze: " + penize);
            Console.WriteLine("Karma: " + karma);

            if (zbran == "2" || zbran == "3")
            {
                Console.WriteLine("Zbraň: Ano");
                Console.WriteLine("Náboje: " + naboje);
            }
            else
            {
                Console.WriteLine("Zbraň: Ne");
            }

            Console.WriteLine("Štěstí: " + stesti3);
            Console.WriteLine("Vztah s charitou: " + charita_vztah);
            
            return;
        }
    }
    else
    {
        if (zbran == "2" || zbran == "3")
        {
            Console.WriteLine("\nPodle mapy by měl být poklad blízko. Dojdeš k místu, kde je na mapě křížek a vidíš člověka s lopatou, jak vykopává poklad. Napadne tě strašlivý plán, poněvadž máš u sebe zbraň. Chceš hledače pokladů pomocí zbraně okrást, nebo se ho pokusíš přemluvit?");
            Console.WriteLine("1. Pokusit se ho okrást");
            Console.WriteLine("2. Pokusit taktiku přemlouvání");

            string cast_26_hledac = Console.ReadLine();

            if (cast_26_hledac == "1")
            {
                uspesne_premlouvani = 0;
                cast_26_konec = 1;
                karma--;

                if (stamina < 50)
                {
                    kola++;
                }
                stamina -= 10;
                kola++;

                int cast_26_priklad_konec = 0;
                while (cast_26_priklad_konec != 1)
                {
                    Random cislo1 = new Random();
                    int cislo1_1 = cislo1.Next(1, 1000);

                    Random cislo2 = new Random();
                    int cislo2_1 = cislo2.Next(1, 1000);

                    Console.Clear();
                    Console.WriteLine("Vypočti:");
                    Console.WriteLine(cislo1_1 + " + " + cislo2_1);
                    int odpoved = int.Parse(Console.ReadLine());
                    int spravna_odpoved = cislo1_1 + cislo2_1;

                    if (odpoved == spravna_odpoved)
                    {
                        cast_26_priklad_konec = 1;

                        Console.WriteLine("\nVýborně, správná odpověď.");
                        Console.ReadLine();
                    }
                    else
                    {
                        kola++;
                        Console.WriteLine("\nBohužel špatně, musíš příklad zopakovat.");
                        Console.ReadLine();
                    }
                }
            }
            else if (cast_26_hledac == "2")
            {
                cast_26_konec = 1;

                Random premlouvani = new Random();
                int premlouvani1 = premlouvani.Next(1, 100);

                if (premlouvani1 < 50)
                {
                    uspesne_premlouvani = 1;
                }
                else
                {
                    uspesne_premlouvani = 0;
                }
            }
        }
        else if (vec1 == "4" || vec2 == "4" || vec3 == "4" || vec4 == "4")
        {
            Console.WriteLine("\nPodle mapy by měl být poklad blízko. Dojdeš k místu, kde je na mapě křížek a vidíš člověka s lopatou, jak vykopává poklad. Napadne tě strašlivý plán, poněvadž máš u sebe nůž. Chceš hledače pokladů pomocí nože okrást, nebo se ho pokusíš přemluvit?");
            Console.WriteLine("1. Pokusit se ho okrást");
            Console.WriteLine("2. Pokusit taktiku přemlouvání");

            string cast_26_hledac = Console.ReadLine();

            if (cast_26_hledac == "1")
            {
                uspesne_premlouvani = 0;
                cast_26_konec = 1;
                karma--;

                if (stamina < 50)
                {
                    kola++;
                }
                stamina -= 10;
                kola++;

                int cast_26_priklad_konec = 0;
                while (cast_26_priklad_konec != 1)
                {
                    Random cislo1 = new Random();
                    int cislo1_1 = cislo1.Next(1, 1000);

                    Random cislo2 = new Random();
                    int cislo2_1 = cislo2.Next(1, 1000);

                    Console.Clear();
                    Console.WriteLine("Vypočti:");
                    Console.WriteLine(cislo1_1 + " + " + cislo2_1);
                    int odpoved = int.Parse(Console.ReadLine());
                    int spravna_odpoved = cislo1_1 + cislo2_1;

                    if (odpoved == spravna_odpoved)
                    {
                        cast_26_priklad_konec = 1;

                        Console.WriteLine("\nVýborně, správná odpověď.");
                        Console.ReadLine();
                    }
                    else
                    {
                        kola++;
                        Console.WriteLine("\nBohužel špatně, musíš příklad zopakovat.");
                        Console.ReadLine();
                    }
                }
            }
            else if (cast_26_hledac == "2")
            {
                cast_26_konec = 1;

                Random premlouvani = new Random();
                int premlouvani1 = premlouvani.Next(1, 100);

                if (premlouvani1 < 50)
                {
                    uspesne_premlouvani = 1;
                }
                else
                {
                    uspesne_premlouvani = 0;
                }
            }
        }
        else
        {
            Console.WriteLine("\nPodle mapy by měl být poklad blízko. Dojdeš k místu, kde je na mapě křížek a vidíš člověka s lopatou, jak vykopává poklad. Řekneš si, že se ho pokusíš přemluvit, aby se o poklad rozdělil s tebou. Chceš se pokusit hledače přemluvit?");
            Console.WriteLine("1. Ano");

            string cast_26_premlouvani = Console.ReadLine();

            if (cast_26_premlouvani == "1")
            {
                cast_26_konec = 1;

                Random premlouvani = new Random();
                int premlouvani1 = premlouvani.Next(1, 100);

                if (premlouvani1 < 50)
                {
                    uspesne_premlouvani = 1;
                }
                else
                {
                    uspesne_premlouvani = 0;
                }
            }
        }
    }
}

if (uspesne_premlouvani == 1)
{
    Console.Clear();
    Console.WriteLine("Máš " + penize + " dolarů");
    Console.WriteLine(kola + ". Kolo");
    Console.WriteLine("Máš " + stamina + " staminy");

    Console.WriteLine("\nSpolečně nakonec poklad vykopáte a rozdělíte si ho rovným dílem.");
    Console.ReadLine();

    Console.Clear();
    Console.WriteLine("Máš " + penize + " dolarů");
    Console.WriteLine(kola + ". Kolo");
    Console.WriteLine("Máš " + stamina + " staminy");

    Console.WriteLine("\nBohužel hledač pokladu neměl dobré srdce a nedodržel vaši dohodu a pokouší ti celý poklad odcizit.");
    Console.ReadLine();

    int cast_28_priklad_konec = 0;
    while (cast_28_priklad_konec != 1)
    {
        Random cislo1 = new Random();
        int cislo1_1 = cislo1.Next(1, 1000);

        Random cislo2 = new Random();
        int cislo2_1 = cislo2.Next(1, 1000);

        Console.Clear();
        Console.WriteLine("Vypočti:");
        Console.WriteLine(cislo1_1 + " + " + cislo2_1);
        int odpoved = int.Parse(Console.ReadLine());
        int spravna_odpoved = cislo1_1 + cislo2_1;

        if (odpoved == spravna_odpoved)
        {
            cast_28_priklad_konec = 1;

            Console.WriteLine("\nVýborně, správná odpověď. Jeho pokus zarazíš a on radši se svým podílem uteče a ty získáváš 250 dolarů.");
            Console.ReadLine();
            penize += 250;

            if (stamina < 50)
            {
                kola++;
            }
            stamina -= 10;
            kola++;
        }
        else
        {
            karma--;
            Console.WriteLine("\nBohužel špatně, musíš příklad zopakovat.");
            Console.ReadLine();
        }
    }

    Console.Clear();
    Console.WriteLine("Máš " + penize + " dolarů");
    Console.WriteLine(kola + ". Kolo");
    Console.WriteLine("Máš " + stamina + " staminy");

    Console.WriteLine("\nPoněvadž máš dostatek peněz, dopravíš se k převozníkovi a zaplatíš mu bezpečnou cestu domů. On tě převeze do přístavu, odkud odjíždíš lodí směrem k domovu. Zpáteční cesta byla sice kratší, ale i tak velmi dlouhá.");
    penize -= 30;
    Console.ReadLine();
}
else
{
    Console.Clear();
    Console.WriteLine("Máš " + penize + " dolarů");
    Console.WriteLine(kola + ". Kolo");
    Console.WriteLine("Máš " + stamina + " staminy");

    Console.WriteLine("\nHledače pokladu si byl nucen svázat u stromu a sám si vykopal poklad. Při odchodu ti ho bylo líto, a tak si ho odvázal a dal mu pár dolarů na usmířenou. Ty tím pádem získáváš 450 dolarů.");
    Console.ReadLine();
    penize += 450;

    Console.Clear();
    Console.WriteLine("Máš " + penize + " dolarů");
    Console.WriteLine(kola + ". Kolo");
    Console.WriteLine("Máš " + stamina + " staminy");

    Console.WriteLine("\nPoněvadž máš dostatek peněz, dopravíš se k převozníkovi a zaplatíš mu bezpečnou cestu domů. On tě převeze do přístavu, odkud odjíždíš lodí směrem k domovu. Zpáteční cesta byla sice kratší, ale i tak velmi dlouhá.");
    penize -= 30;
    Console.ReadLine();
}

Console.Clear();
Console.WriteLine("Máš " + penize + " dolarů");
Console.WriteLine(kola + ". Kolo");
Console.WriteLine("Máš " + stamina + " staminy");

Console.WriteLine("\nPo dlouhé době se setkáváš zase s rodinou, která tě velmi ráda vidí. Přijel jsi právě včas, poněvadž stav tvé dcery se velmi zhoršil. Hned příští den jdete do nejlepší nemocnice, kde dcerce zaplatíte nejlepšího lékaře, který stojí 200 dolarů.");
Console.ReadLine();
penize -= 200;

Console.Clear();
Console.WriteLine("Máš " + penize + " dolarů");
Console.WriteLine(kola + ". Kolo");
Console.WriteLine("Máš " + stamina + " staminy");

Console.WriteLine("\nLéčba po několika měsících dopadla úspěšně a dcerka se zcela zotavila. Konečně můžeš s rodinou žít šťastný život, o kterém si vždycky snil.");
Console.ReadLine();

Console.Clear();
Console.WriteLine("Toto je konec tvé cesty. Zde máš ještě ukázané nějaké statistiky, které byly pro tebe celou hru skryty.");

int stesti = karma * 10 + 40;

Console.WriteLine("\nKola: " + kola);
Console.WriteLine("Stamina: " + stamina);
Console.WriteLine("Peníze: " + penize);
Console.WriteLine("Karma: " + karma);

if (zbran == "2" || zbran == "3")
{
    Console.WriteLine("Zbraň: Ano");
    Console.WriteLine("Náboje: " + naboje);
}
else
{
    Console.WriteLine("Zbraň: Ne");
}

Console.WriteLine("Štěstí: " + stesti);
Console.WriteLine("Vztah s charitou: " + charita_vztah);